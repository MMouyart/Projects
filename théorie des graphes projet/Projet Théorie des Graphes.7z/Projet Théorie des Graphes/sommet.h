#ifndef SOMMET_H_INCLUDED
#define SOMMET_H_INCLUDED
#include <vector>
class Sommet
{
    protected :
        //int m_dist;
        int m_coordX;
        float m_VectPropre;
        int m_coordY;
        char m_nom;
        float m_centralProxim;
        int m_num;
        int m_degre;
        float m_degreN;
        std::vector< Sommet*> m_successeurs;


    public :
        Sommet(int num, char nom, int coordX, int coordY);

        int getDegre();
        float getVectPropre();
        void setVectPropre(float i);
        float getDegreN();
        void setDegreN(float i);
        void setDegre(int deg);
        char getNom();
        int getCoordX();
        int getCoordY();
        int getNum(){return m_num;}
        const std::vector< Sommet*>& getSuccesseurs()const {return m_successeurs;}
        void setCentralProx(float prox){ m_centralProxim= prox;}
        float getCentralProx(){ return m_centralProxim;}














        void ajouterSucc( Sommet*s)
        {
            m_successeurs.push_back(s);
        }


        //const std::vector<const Sommet*>& getSuccesseurs()const {return m_successeurs;}

        //int getDist();
        //Sommet* getPere();
        //void setDist(int dist);
        //void setPere(Sommet* pere);

};



#endif // SOMMET_H_INCLUDED
