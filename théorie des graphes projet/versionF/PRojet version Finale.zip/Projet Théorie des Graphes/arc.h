#ifndef ARC_H_INCLUDED
#define ARC_H_INCLUDED

struct Arc
{
    int idA, e, s, p;
};

#endif // ARC_H_INCLUDED
